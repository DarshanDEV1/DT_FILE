from tkinter import *
import csv

root = Tk()

root.minsize(800, 300)
root.maxsize(800, 300)

bgc = "wheat"
fgc = "black"

root.config(bg=bgc)

root.title("Darshan's Technologies(D.TECH)")

Label(root, text="DARSHAN'S TECHNOLOGIES(D-TECH)", fg=fgc, bg=bgc, font="Stencil 30 bold underline").pack()

Label(root, text="IMAGINATION ENDS AND IMPLEMENTATION BEGINS", fg=fgc, bg=bgc,
      font="Stencil 20 underline italic").pack()

frame = Frame(root, bg=bgc)
frame.pack()

Label(frame, text="Area to enter the data direct to the data base", font="Times 15 underline", bg=bgc, fg=fgc).grid(
    row=0, column=2)

Label(frame, text="Name:--- ", font="Times 10", bg=bgc, fg=fgc).grid(row=1, column=0)

name = StringVar()
Entry(frame, textvariable=name, bd=3, font="Times", bg="grey").grid(row=1, column=2)

Label(frame, text="Work:--- ", font="Times 10", bg=bgc, fg=fgc).grid(row=6, column=0)

work = StringVar()
Entry(frame, textvariable=work, bd=3, font="Times", bg="grey").grid(row=6, column=2)

fill_title = StringVar()
Label(frame, text="title_here", font="Times 10 underline", bg=bgc, fg=fgc).grid()
Entry(frame, textvariable=fill_title, width=20, bg="grey").grid()


def append(event):
    with open(f"{fill_title.get()}", 'a') as file:
        pen = csv.writer(file)
        pen.writerow([f"{name.get()}", f"{work.get()}"])


btn = Button(frame, text="submit", bd=5, bg=bgc, fg=fgc, command=append)
btn.bind("<Return>", append)
btn.grid(row=10, column=2)

end_frame = Frame(root, bd=10, bg=bgc)
end_frame.pack(side="right")


def end(event):
    root.destroy()


end_btn = Button(end_frame, text="exit", bd=5, bg=bgc, command=end)
end_btn.bind("<Control-q>", end)
end_btn.grid(row=7, column=3)

root.mainloop()
